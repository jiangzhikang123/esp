#include    <stdio.h>

#include    "esp_log.h"
#include    "driver/spi_master.h"
#include    "driver/ledc.h"
#include    "esp_sleep.h"

#include    "io_extend.h"
#include    "esp_err.h"
#include    "bsp_driver.h"
#include    "camera.h"


//----------------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------------

//definition

//----------------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------------


static const char* TAG="bsp_driver";
#define BSP_BUTTON_IO   GPIO_NUM_0


//----------------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------------

// declaration

//----------------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------------


esp_err_t bsp_display_brightness_init(void);


//gpio interrupt service routine
static void IRAM_ATTR gpio_isr_handler(void* arg);



//----------------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------------

// gap

//----------------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------------



//----------------------------------------------------------------------------------------------------------
// ----------------------------------------- i2c New Version -----------------------------------------------------
//----------------------------------------------------------------------------------------------------------

i2c_master_bus_handle_t     I2C_Master_bus_handle;
i2c_master_dev_handle_t     I2C_Master_io_extend_dev_handle;


/**
 * @brief Initialize the I2C master bus and add the IO extender device.
 *
 * Sets up the I2C bus (I2C_NUM_0) and registers the IO extender device on
 * the bus. This is the new-version I2C initialization used by the board.
 */
void   bsp_i2c_driver_init(void)
{

    // Initialize the I2C bus
    i2c_master_bus_config_t bus_config = {
        .i2c_port = I2C_NUM_0,
        .sda_io_num = EXAMPLE_I2C_SDA_IO,
        .scl_io_num = EXAMPLE_I2C_SCL_IO,
        .clk_source = I2C_CLK_SRC_DEFAULT,
        .glitch_ignore_cnt = 7,
        .flags.enable_internal_pullup = true,
    };
    ESP_ERROR_CHECK(i2c_new_master_bus(&bus_config, &I2C_Master_bus_handle));


    i2c_device_config_t dev_config = {
        .dev_addr_length = I2C_ADDR_BIT_LEN_7,
        .device_address = (0x32>>1),           //io extender 7 bit address
        .scl_speed_hz = EXAMPLE_I2C_BUS_FRE,
    };
    
    ESP_ERROR_CHECK(i2c_master_bus_add_device(I2C_Master_bus_handle, &dev_config, &I2C_Master_io_extend_dev_handle));

}




//----------------------------------------------------------------------------------------------------------
// ----------------------------------------- LCD Related -----------------------------------------------------
//----------------------------------------------------------------------------------------------------------

// Define the LCD screen handle
esp_lcd_panel_handle_t      lcd_panel_handle = NULL;    // TFT LCD panel handle
esp_lcd_panel_io_handle_t   lcd_io_handle = NULL;       // tft lcd spi handle
esp_lcd_touch_handle_t      tp_handle;                  // Touchscreen handle



/**
 * @brief Initialize and configure the LCD panel and associated SPI bus.
 *
 * Initializes SPI bus, installs panel IO, creates the ST7789 panel driver,
 * performs panel reset and basic configuration. Returns an esp_err_t to
 * indicate success or failure.
 *
 * @return ESP_OK on success, or an error code on failure.
 */
// LCD screen initialization
esp_err_t bsp_display_new(void)
{
    esp_err_t ret = ESP_OK;
    // Backlight Initialization
    ESP_RETURN_ON_ERROR(bsp_display_brightness_init(), TAG, "Brightness init failed");
    // Initialize the SPI bus
    ESP_LOGD(TAG, "Initialize SPI bus");
    const spi_bus_config_t buscfg = {
        .sclk_io_num = BSP_LCD_SPI_CLK,
        .mosi_io_num = BSP_LCD_SPI_MOSI,
        .miso_io_num = GPIO_NUM_NC,
        .quadwp_io_num = GPIO_NUM_NC,
        .quadhd_io_num = GPIO_NUM_NC,
        // .max_transfer_sz = BSP_LCD_H_RES * BSP_LCD_V_RES * sizeof(uint16_t),
        .max_transfer_sz = BSP_LCD_V_RES *20* sizeof(uint16_t),
    };
    ESP_RETURN_ON_ERROR(spi_bus_initialize(BSP_LCD_SPI_NUM, &buscfg, SPI_DMA_CH_AUTO), TAG, "SPI init failed");
    
    // LCD screen control IO initialization
    ESP_LOGD(TAG, "Install panel IO");
    const esp_lcd_panel_io_spi_config_t io_config = {
        .dc_gpio_num = BSP_LCD_DC,
        .cs_gpio_num = BSP_LCD_SPI_CS,
        .pclk_hz = BSP_LCD_PIXEL_CLOCK_HZ,
        .lcd_cmd_bits = LCD_CMD_BITS,
        .lcd_param_bits = LCD_PARAM_BITS,
        .spi_mode = 2,
        .trans_queue_depth = 5,
    };
    ESP_GOTO_ON_ERROR(esp_lcd_new_panel_io_spi((esp_lcd_spi_bus_handle_t)BSP_LCD_SPI_NUM, &io_config, &lcd_io_handle), err, TAG, "New panel IO failed");
   
    // Initialize the LCD driver chip ST7789
    ESP_LOGD(TAG, "Install LCD driver");
    const esp_lcd_panel_dev_config_t panel_config = {
        .reset_gpio_num = BSP_LCD_RST,
        .rgb_ele_order = LCD_RGB_ELEMENT_ORDER_RGB,
        .data_endian=0,
        .bits_per_pixel = BSP_LCD_BITS_PER_PIXEL,
    };
    ESP_GOTO_ON_ERROR(esp_lcd_new_panel_st7789(lcd_io_handle, &panel_config, &lcd_panel_handle), err, TAG, "New panel failed");
    
    esp_lcd_panel_reset(lcd_panel_handle);  // LCD screen reset
    lcd_cs_level(0);  // Pull the CS pin low
    esp_lcd_panel_init(lcd_panel_handle);  // Initialize configuration register
    esp_lcd_panel_invert_color(lcd_panel_handle, true); // Color inversion
    esp_lcd_panel_swap_xy(lcd_panel_handle, true);  // Display flip
    esp_lcd_panel_mirror(lcd_panel_handle, true, false); // Mirror image

    return ret;

err:
    if (lcd_panel_handle) {
        esp_lcd_panel_del(lcd_panel_handle);
    }
    if (lcd_io_handle) {
        esp_lcd_panel_io_del(lcd_io_handle);
    }
    spi_bus_free(BSP_LCD_SPI_NUM);
    return ret;
}



/**
 * @brief Initialize PWM (LEDC) for LCD backlight control.
 *
 * Configures LEDC timer and channel used to drive the LCD backlight via PWM.
 * @return ESP_OK on success, or an error code on failure.
 */
// Backlight PWM Initialization
esp_err_t bsp_display_brightness_init(void)
{
    // Setup LEDC peripheral for PWM backlight control
    const ledc_channel_config_t LCD_backlight_channel = {
        .gpio_num = BSP_LCD_BACKLIGHT,
        .speed_mode = LEDC_LOW_SPEED_MODE,
        .channel = LCD_LEDC_CH,
        .intr_type = LEDC_INTR_DISABLE,
        .timer_sel = 0,
        .duty = 0,
        .hpoint = 0,
        .flags.output_invert = true      // Using a PMOS transistor to drive the LCD backlight, the PWM signal is connected to the gate, so the output needs to be inverted.
    };
    const ledc_timer_config_t LCD_backlight_timer = {
        .speed_mode = LEDC_LOW_SPEED_MODE,
        .duty_resolution = LEDC_TIMER_10_BIT,
        .timer_num = 0,
        .freq_hz = 5000,
        .clk_cfg = LEDC_AUTO_CLK

    };

    ESP_ERROR_CHECK(ledc_timer_config(&LCD_backlight_timer));
    ESP_ERROR_CHECK(ledc_channel_config(&LCD_backlight_channel));

    return ESP_OK;
}

/**
 * @brief Set the LCD backlight brightness.
 *
 * Converts a percentage (0-100) to the LEDC duty cycle and updates the
 * PWM output driving the backlight.
 *
 * @param brightness_percent Brightness as percentage (0-100).
 * @return ESP_OK on success, or an error code on failure.
 */
// Backlight Brightness Setting
esp_err_t bsp_display_brightness_set(int brightness_percent)
{
    if (brightness_percent > 100) {
        brightness_percent = 100;
    } else if (brightness_percent < 0) {
        brightness_percent = 0;
    }

    // ESP_LOGI(TAG, "Setting LCD backlight: %d%%", brightness_percent);

    // LEDC resolution set to 10bits, thus: 100% = 1023
    uint32_t duty_cycle = (1023 * brightness_percent) / 100;
    ESP_ERROR_CHECK(ledc_set_duty(LEDC_LOW_SPEED_MODE, LCD_LEDC_CH, duty_cycle));
    ESP_ERROR_CHECK(ledc_update_duty(LEDC_LOW_SPEED_MODE, LCD_LEDC_CH));

    return ESP_OK;
}

/**
 * @brief Turn off the display backlight.
 *
 * Convenience wrapper that sets backlight brightness to 0%.
 * @return ESP_OK on success.
 */
// Turn off the backlight
esp_err_t bsp_display_backlight_off(void)
{
    return bsp_display_brightness_set(0);
}

/**
 * @brief Turn on the display backlight at maximum brightness.
 *
 * Convenience wrapper that sets backlight brightness to 100%.
 * @return ESP_OK on success.
 */
// Turn on the backlight to the brightest setting.
esp_err_t bsp_display_backlight_on(void)
{
    return bsp_display_brightness_set(100);
}


/**
 * @brief Fill a rectangular region of the LCD with a single RGB color.
 *
 * Allocates a temporary buffer for one row and writes the provided color
 * to each pixel in the rectangle bounded by (x_start,y_start)-(x_end,y_end).
 *
 * @param x_start Left coordinate of the rectangle.
 * @param y_start Top coordinate of the rectangle.
 * @param x_end Right coordinate of the rectangle (exclusive/end).
 * @param y_end Bottom coordinate of the rectangle (exclusive/end).
 * @param rgb_color 16-bit RGB color value.
 */
// Set the LCD screen color
void lcd_set_color(int x_start, int y_start, int x_end, int y_end, uint16_t rgb_color)
{
    // Swap high and low bytes
    volatile uint16_t color_swap= ((((uint8_t)rgb_color)<<8)|((uint8_t)(rgb_color>>8)));
   
    // Allocate memory: here, the size needed for one row of data on the LCD screen is allocated.
    uint16_t *buffer = (uint16_t *)heap_caps_malloc(BSP_LCD_H_RES * sizeof(uint16_t), MALLOC_CAP_8BIT | MALLOC_CAP_SPIRAM);

    if (NULL == buffer)
    {
        ESP_LOGE(TAG, "Memory for bitmap is not enough");
    }
    else
    {
        ESP_LOGI(TAG,"set screen back  color");
        
        for (size_t i = 0; i < (x_end -x_start); i++) // Put color data into the cache.
        {
            buffer[i] = color_swap;
        }
        for (int y = y_start; y < y_end; y++) // Display full-screen color
        {
            esp_lcd_panel_draw_bitmap(lcd_panel_handle, x_start, y, x_end, y+1, buffer);
        }
        free(buffer); // Release memory
    }
}



/**
 * @brief Draw an image to the LCD panel.
 *
 * Copies image pixel data into a heap-allocated buffer and draws it to the
 * specified rectangle on the display.
 *
 * @param x_start Left coordinate of the destination rectangle.
 * @param y_start Top coordinate of the destination rectangle.
 * @param x_end Right coordinate of the destination rectangle.
 * @param y_end Bottom coordinate of the destination rectangle.
 * @param gImage Pointer to image data to be drawn (byte-packed).
 */
void lcd_draw_pictrue(int x_start, int y_start, int x_end, int y_end, const unsigned char *gImage)
{
    
    ESP_LOGI(TAG,"begin draw test pic on  tft lcd ");
    size_t pixels_byte_size = (x_end - x_start)*(y_end - y_start) * 2;
    uint16_t *pixels = (uint16_t *)heap_caps_malloc((240 * 320) * sizeof(uint16_t), MALLOC_CAP_8BIT | MALLOC_CAP_SPIRAM);
    if (NULL == pixels)
    {
        ESP_LOGE(TAG, "Memory for bitmap is not enough");
        return;
    }
    memcpy(pixels, gImage, pixels_byte_size);  // Copy the image data to memory

    esp_lcd_panel_draw_bitmap(lcd_panel_handle, x_start,y_start, x_end, y_end, (uint16_t *)pixels);
    heap_caps_free(pixels);

}







//----------------------------------------------------------------------------------------------------------
// ----------------------------------------- lcd touch related -----------------------------------------------------
//----------------------------------------------------------------------------------------------------------
esp_lcd_touch_handle_t      tp_handle;                  // Touchscreen handle
esp_lcd_panel_io_handle_t   tp_io_handle;

/**
 * @brief Initialize the touch controller and create touch IO handle.
 *
 * Creates the panel IO for I2C touch controller and instantiates the
 * ft5x06 touch driver with configured geometry and flags.
 */
void  bsp_touch_new(void)
{
    ESP_LOGI(TAG,"begin to init tft touch ");

    esp_lcd_panel_io_i2c_config_t   io_config = ESP_LCD_TOUCH_IO_I2C_FT5x06_CONFIG();
    io_config.scl_speed_hz=100000;

    // 4. Create Panel IO Handle
    esp_lcd_new_panel_io_i2c(I2C_Master_bus_handle, &io_config, &tp_io_handle);

    esp_lcd_touch_config_t tp_cfg = {
        .x_max = BSP_LCD_V_RES,         //240
        .y_max = BSP_LCD_H_RES ,        //320
        .rst_gpio_num = -1,
        .int_gpio_num = -1,
        .levels = 
        {
            .reset = 0,
            .interrupt = 0,
        },
        .flags = 
        {
            .swap_xy = 1,
            .mirror_x = 1,
            .mirror_y = 0,
        },
    };

    esp_lcd_touch_new_i2c_ft5x06(tp_io_handle, &tp_cfg, &tp_handle);


}


/**
 * @brief Task function that polls touch controller and reports coordinates.
 *
 * Intended to run as a FreeRTOS task; periodically reads touch data and
 * logs coordinates when a touch is detected.
 *
 * @param par Unused parameter pointer passed by the task create API.
 */
void tft_touch_read_data(void* par)
{
    uint16_t touch_x[1];
    uint16_t touch_y[1];
    uint16_t touch_strength[1];
    uint8_t touch_cnt = 0;
    bool touchpad_pressed ;
    ESP_LOGI(TAG,"touch detect task begin run !");
    while(1)
    {
        esp_lcd_touch_read_data(tp_handle);

        // 2. Retrieve the parsed coordinate data from the tp handle.
        touchpad_pressed = esp_lcd_touch_get_coordinates(tp_handle, touch_x, touch_y, touch_strength, &touch_cnt, 1);
        // 3. Check if there is a touch point
        if (touchpad_pressed) 
        {
            ESP_LOGI(TAG, "Touch detected! x=%d, y=%d, strength=%d",
                     touch_x[0], touch_y[0], touch_strength[0]);
   
        } 

        // 4. Wait for a period of time before polling again.
        vTaskDelay(pdMS_TO_TICKS(50)); // For example, poll every 50 milliseconds.
    }
}


//----------------------------------------------------------------------------------------------------------
// ----------------------------------------- Display and Touch Initialization Related -----------------------------------
//----------------------------------------------------------------------------------------------------------

lv_display_t *lvgl_disp= NULL;
static lv_indev_t *lvgl_touch_indev = NULL;


/**
 * @brief Initialize LVGL, register display and touch drivers.
 *
 * Sets up LVGL port, registers the display driver and touch input driver
 * and performs required display initialization steps.
 *
 * @return ESP_OK on success or an error code on failure.
 */
esp_err_t app_lvgl_init(void)
{
    //initialize lcd display , ledc (to control the lcd light), spi (to driver the lcd )
    bsp_display_new();
    
    //set  screen color white
    lcd_set_color(0,0,BSP_LCD_H_RES,BSP_LCD_V_RES,0xffff);

    //turn on  display
    esp_lcd_panel_disp_on_off(lcd_panel_handle,true);

    
    //open background light
    bsp_display_backlight_on();

    
    /* Initialize LVGL */
    const lvgl_port_cfg_t lvgl_cfg = {
        .task_priority = 15,         /* LVGL task priority */
        .task_stack = 6144,         /* LVGL task stack size */
        .task_affinity =0,        /* LVGL task pinned to core (-1 is no affinity) */
        .task_max_sleep_ms = 500,   /* Maximum sleep in LVGL task */
        .timer_period_ms = 5        /* LVGL timer tick period in ms */
    };
    ESP_RETURN_ON_ERROR(lvgl_port_init(&lvgl_cfg), TAG, "LVGL port initialization failed");

    /* Add LCD screen */
    ESP_LOGD(TAG, "Add LCD screen");
    const lvgl_port_display_cfg_t disp_cfg = {
        .io_handle = lcd_io_handle,
        .panel_handle = lcd_panel_handle,
        .buffer_size = 320 * 120,
        .double_buffer = 1,
        .hres = 320,
        .vres = 240,
        .monochrome = false,

        .rotation = {
            .swap_xy = true,
            .mirror_x = true,
            .mirror_y = false,
        },
        .flags = {
            .buff_dma = false,   // The rendering buffer is allocated in internal SRAM.
            .buff_spiram=true,   // Render buffer allocated in PSRAM
        }
    };
    lvgl_disp = lvgl_port_add_disp(&disp_cfg);

    //initialize
    bsp_touch_new();

    /* Add touch input (for selected screen) */
    const lvgl_port_touch_cfg_t touch_cfg = {
        .disp = lvgl_disp,
        .handle = tp_handle,
    };
    lvgl_touch_indev = lvgl_port_add_touch(&touch_cfg);

    return ESP_OK;
}





//----------------------------------------------------------------------------------------------------------
// ----------------------------------------- Key Detection -----------------------------------
//----------------------------------------------------------------------------------------------------------



/**
 * @brief Configure the user button GPIO and install ISR.
 *
 * Configures GPIO0 as input with pull-up and attaches an ISR to handle
 * button presses. ISR either queues a camera store command or enters
 * deep sleep if the camera queue is not present.
 */
void bsp_button_init(void)
{
    gpio_config_t gpio_conf = {
        .intr_type = GPIO_INTR_POSEDGE,     // positive interrupt
        .mode = GPIO_MODE_INPUT,            // input
        .pin_bit_mask = 1<<BSP_BUTTON_IO,   // GPIO
        .pull_down_en = 0,                 
        .pull_up_en = 1                     // enable internal pull up
    };
    // Set up the GPIO according to the above configuration.
    gpio_config(&gpio_conf);

    gpio_install_isr_service(0);

    
    // Add interrupt handling for GPIO0
    gpio_isr_handler_add(BSP_BUTTON_IO, gpio_isr_handler, (void *)BSP_BUTTON_IO);

}



/**
 * @brief GPIO interrupt service routine for the user button (GPIO0).
 *
 * If the camera event queue exists, this ISR posts a store command. If
 * not, it configures an ext0 wakeup and enters deep sleep.
 *
 * @param arg GPIO number passed as the ISR argument.
 */
static void IRAM_ATTR gpio_isr_handler(void* arg)
{
    uint32_t io_num=(int)arg;
    if(io_num !=BSP_BUTTON_IO)
    {
        return ;
    }
    
    //when g_Camera_event_queue is not empty, 
    //it indicates a photo capture request is to be sent.
    if(g_Camera_event_queue)
    {
        BaseType_t xHigherPriorityTaskWoken;
        camera_command_t cmd;
        cmd.type=CAMER_CMD_STORE;
        cmd.data=NULL;

        xQueueSendFromISR(g_Camera_event_queue, &cmd, &xHigherPriorityTaskWoken); // Send the input parameter value to the queue
    
        if(xHigherPriorityTaskWoken)
        {
            // Actual macro used here is port specific.
            portYIELD_FROM_ISR ();
        }

    }
    //now means enter deep sleep mode 
    else
    {
        //configure gpio wake up ,when GPIO_NUM_O level=0 wake up whole system
        esp_sleep_enable_ext0_wakeup(GPIO_NUM_0, 0); 

        //enter deep sleep mode
        esp_deep_sleep_start();


    }

    
}

