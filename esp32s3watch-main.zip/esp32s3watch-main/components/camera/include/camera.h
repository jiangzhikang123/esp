#pragma once

#include    "esp_err.h"
#include    "esp_camera.h"

//use pin defination
#define CAMERA_PIN_PWDN -1
#define CAMERA_PIN_RESET -1
#define CAMERA_PIN_XCLK 5
#define CAMERA_PIN_SIOD 1
#define CAMERA_PIN_SIOC 2
#define CAMERA_PIN_D7 9
#define CAMERA_PIN_D6 4
#define CAMERA_PIN_D5 6
#define CAMERA_PIN_D4 15
#define CAMERA_PIN_D3 17
#define CAMERA_PIN_D2 8
#define CAMERA_PIN_D1 18
#define CAMERA_PIN_D0 16
#define CAMERA_PIN_VSYNC 3
#define CAMERA_PIN_HREF 46
#define CAMERA_PIN_PCLK 7

#define XCLK_FREQ_HZ 24000000


extern int  camera_frame_save_file_counter;

//picture's saved path 
#define  CAMERA_SAVED_PIC_PATH      "/sdcard/camera"

typedef enum {

    // Save the current frame
    CAMER_CMD_STORE,

} camera_command_type_t;

typedef struct 
{
    camera_command_type_t type;
    void *data; // Use a generic pointer to pass data.
} camera_command_t;


extern QueueHandle_t    g_Camera_event_queue;  


esp_err_t bsp_camera_init(void);

void bsp_camera_deinit(void);

void app_camera_lcd(void);

void camera_dvp_pwdn_set(uint8_t level);


void save_frame_to_bmp(const char* out_image) ;


void camera_register_camera_handler(void);
